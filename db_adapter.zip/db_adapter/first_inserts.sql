INSERT INTO kinds_of_users (kind)
VALUES ("Administrator");

INSERT INTO kinds_of_users (kind)
VALUES ("Head of Unit");

INSERT INTO kinds_of_users (kind)
VALUES ("University Administrator");
